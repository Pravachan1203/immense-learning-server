-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2025 at 04:51 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `class`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--
-- Error reading structure for table class.attendance: #1932 - Table &#039;class.attendance&#039; doesn&#039;t exist in engine
-- Error reading data for table class.attendance: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `class`.`attendance`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `class_notes`
--
-- Error reading structure for table class.class_notes: #1932 - Table &#039;class.class_notes&#039; doesn&#039;t exist in engine
-- Error reading data for table class.class_notes: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `class`.`class_notes`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `recorded_classes`
--
-- Error reading structure for table class.recorded_classes: #1932 - Table &#039;class.recorded_classes&#039; doesn&#039;t exist in engine
-- Error reading data for table class.recorded_classes: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `class`.`recorded_classes`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `students`
--
-- Error reading structure for table class.students: #1932 - Table &#039;class.students&#039; doesn&#039;t exist in engine
-- Error reading data for table class.students: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `class`.`students`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--
-- Error reading structure for table class.teachers: #1932 - Table &#039;class.teachers&#039; doesn&#039;t exist in engine
-- Error reading data for table class.teachers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `class`.`teachers`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
